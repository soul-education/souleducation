Buffalo PC icons library I

This set of icons are for free use, If you have a website and you�re going to post them, this text file must be on the zip file.


Victor Hugo Reyna
Copyright Buffalo PC 1999
http://www.Jamiroquai.com/pc