Jamiroquai Virtual Insanity Screens Pack v1.0 by Nenad Smoljanec

Thank you for downloading my Jamiroquai Virtual Insanity Screens Pack.
It took me a lot of time making this Theme, so I'd like you to let
me know what you think of it. Tell me what you like or dislike and
I will try to update this pack as much as I can.
Send e-mail with all comments to:
live@usa.net
http://www.nenad.net

INSTRUCTIONS ON INSTALLING THE PACK
-----------------------------------
Startup screen installation

To install the wonderful Windows 95 startup screen, simply copy the LOGO.SYS
file from the ZIP file to the root of your C:\ The next time you start Windows
you'll be amazed with another splash screen. To install the shutdown screens,
simply copy the LOGOS.SYS and the LOGOW.SYS to your Windows directory (C:\Windows).

THANKS
------
Thanks to Jamiroquai's official website jamiroqaui.co.uk with providing us (and me)
with all great pictures, logos and sounds, and up to date info...
And thanks to all of you who downloaded this Pack... 
Hope you'll enjoy it.

Nenad Smoljanec
live@usa.net
nenad@nenad.net
"now don't ask me questions or I will retreat
 fame is a cancer and ego its seed
 now I wasn't looking for heaven or hell
 just someone to listen to stories I tell"
                                      *****
Jamiroquai Virtual Insanity Screens Pack is provided on an "as is" basis 
without warranty of any kind, expressed or implied, including but not 
limited to the implied warranties of merchantability and fitness for a 
particular purpose. The entire risk as to quality and performance of 
this program is with you. In no event will Nenad Smoljanec be liable to
you for any damages, including any lost profits, lost savings, or other
incidental or consequential damages arising out of the use or inability
to use this program, even if Nenad Smoljanec has been advised of the
possibility of such damages.